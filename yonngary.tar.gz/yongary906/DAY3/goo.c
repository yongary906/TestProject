// goo.c

#include <stdio.h>
#include <goo.h>

void goo() {	printf("goo : %d\n", GOO);	}

