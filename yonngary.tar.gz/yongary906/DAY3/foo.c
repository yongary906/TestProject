// foo.c
#include <stdio.h>
#include <foo.h>

void foo() {	printf("foo : %d\n", FOO);	}

