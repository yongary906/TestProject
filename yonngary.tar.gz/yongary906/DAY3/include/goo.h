// goo.h
#define GOO 200

void goo();
