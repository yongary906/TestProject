// app.c
#include <stdio.h>
#include <app.h>

int main()
{
	printf("%d\n", MAX);
}

