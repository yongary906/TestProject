#!/bin/bash

# awk_test

# 1. 기본 모양 - 원하는 필드를 출력..
#awk '{print $1, $2, $8}' data.txt

# 2. 정규표현식 사용 가능 - '/원하는 표현식/'
#awk '/sshd/' data.txt	# sshd를 검색해 달라.

#awk '/sshd/{print $3, $8}' data.txt	# 정규 표현식 + print

# 3. 산술 및 논리연산도 가능 - '  '로 묶어서 사용
#awk '$3 > 10000' data.txt	# PID가 10000 이상인 경우 출력

#awk '$3 > 10000 {print $8}' data.txt	# PID가 10000 이상인 경우의 프로세스 이름($8)만 출력

# '/   /'	: 정규표현식
# '     '	: 산술 및 논리 연산
# '{   }'	: print 및 제어(if, while)구문들

# 4. {} 안에는 스크립트 제어 명령어를 사용한 프로그램이 가능합니다.
#awk '{ max = ($2 > $3 ) ? $2:$3; print max}' data.txt

# 5. awk 내장 변수
#awk '{print NR, NF, $NF}' data.txt	# NR : 라인넘버,	NF : 필드 갯수, $NF : 마지막필드문자열


# 6. BEGIN, END
#awk 'BEGIN{FS="";OFS="\t";ORS="\n\n"}{print$1, $2, $3}END{print "total record is " NR}' data.txt



awk 'BEGIN {	print "-----------------------------------------------------------"
				printf "%10s %10s %10s\n", "ID", "PASSWD", "UID"
				print "-----------------------------------------------------------"}
				$2 > 10000 { printf "%10s %10s %10s\n", $1, $2, $3}
	END		{print "------------------------------------------------------------"}' data.txt



