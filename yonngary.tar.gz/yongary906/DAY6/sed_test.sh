#!/bin/bash


# sed_test

# data file준비
#ls ~ -al > sed_data.txt



# find : 파일검색
# grep : 파일에서 문자열 검색
# awk : 출력
# sed : 파일 조작(변경) 편집기


# 1. sed (stream lined editor) 기본 모양

# sed '명령 옵션' filename	# 파일을 조작하는 함수

# sed '1,3p' sed_data.txt		# 1 ~ 3행까지 출력 p : print

#sed -n '1,3p' sed_data.txt	# 파일의 전체 출력은 하지 말고 명령어만 수행해달라..

# 정규 표현식으로 검색 후 출력. txt문자열을 검색 후 출력해 보세요

#sed -n '/txt/p' sed_data.txt

# d 명령 : 삭제

#sed '1, 10d' sed_data.txt	# 1 ~ 10행 삭제

# s 명령 : 치환
# sed 's/yonghaeyoon/kkk/' sed_test.txt	# 'root'를 'kkk'로 치환.. 첫번째 단어만
sed 's/yonghaeyoon/kkk/g' sed_test.txt   # 'root'를 'kkk'로 치환.. 첫번째 단어만
