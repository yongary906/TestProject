#include <stdio.h>

int main() 
{
	printf("test\n");
	printf("aaa\n");
	printf("hello\n");
}
