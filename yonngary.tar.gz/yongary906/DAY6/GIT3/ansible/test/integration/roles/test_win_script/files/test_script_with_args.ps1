# Test script to make sure the Ansible script module works when arguments are
# passed to the script.

foreach ($i in $args)
{
    Write-Host $i;
}
