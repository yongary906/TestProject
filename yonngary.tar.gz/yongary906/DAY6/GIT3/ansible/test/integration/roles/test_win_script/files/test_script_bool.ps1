Param(
[bool]$boolvariable
)

Write-Host $boolvariable.GetType()
Write-Host $boolvariable
